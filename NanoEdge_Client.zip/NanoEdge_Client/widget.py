# This Python file uses the following encoding: utf-8
import sys
import serial
import time
import struct

from PySide6.QtWidgets import QApplication, QWidget, QFileDialog
from PySide6.QtGui import QFont

# You need to run this command beforehand to generate ui_form.py from your .ui file:
# pyside6-uic form.ui -o ui_form.py
from ui_form import Ui_Widget
class COMPort(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Widget()
        self.ui.setupUi(self)
        self.port, self.baudrate = self.get_serial_params()

        self.ser = None
        self._reading = False
        font = QFont("Consolas", 18, QFont.Bold)
        self.ui.plainTextEditReport.setFont(font)
        self.ui.plainTextEditReport.setStyleSheet("background-color: black; color: white;")

        self.ui.sendStart.clicked.connect(self.start)
        self.ui.sendStop.clicked.connect(self.stop)
        self.ui.pushClear.clicked.connect(self.clear)
        self.ui.pushSend.clicked.connect(self.send_line)
        self.ui.sendFileButton.clicked.connect(self.on_sendFileButton_clicked)
        self.ui.pushEcho.clicked.connect(self.echo)

    def get_serial_params(self):
        port = self.ui.comboPortNumber.currentText().strip()
        baud = int(self.ui.comboBaud.currentText().strip())
        return port, baud

    def start(self):
        if self._reading:
            self.ui.plainTextEditReport.appendPlainText("[INFO] Already reading.")
            return

        try:
            self.port, self.baudrate = self.get_serial_params()
            self.ser = serial.Serial(self.port, self.baudrate, timeout=0.1)
            time.sleep(2)
            self.ser.reset_input_buffer()
            self._reading = True
            buffer = ""

            self.ui.plainTextEditReport.appendPlainText("[OK] Started reading...")

            while self._reading:
                if self.ser.in_waiting:
                    data = self.ser.read(self.ser.in_waiting)
                    buffer += data.decode(errors='ignore')

                    # Normalize line endings
                    lines = buffer.replace('\r\n', '\n').replace('\r', '\n').split('\n')

                    # Keep last partial line in buffer
                    for line in lines[:-1]:
                        self.ui.plainTextEditReport.appendPlainText(line.strip())
                    buffer = lines[-1]  # incomplete line held for next loop

                QApplication.processEvents()  # Keeps UI responsive
                time.sleep(0.05)

        except serial.SerialException as e:
            self.ui.plainTextEditReport.appendPlainText(f"[ERROR] {e}")
        except Exception as ex:
            self.ui.plainTextEditReport.appendPlainText(f"[ERROR] Unexpected: {ex}")
        finally:
            if self.ser and self.ser.is_open:
                self.ser.close()
                self.ui.plainTextEditReport.appendPlainText("[INFO] Serial port closed.")
    def stop(self):
        self._reading = False
        self.ui.plainTextEditReport.appendPlainText("[OK] Reading stopped.")

    def clear(self):
        self.ui.plainTextEditReport.clear()

#anomaly sample:
#-0.34090954,-1.7110015,-3.4240738,-2.152835,-1.7474247,-1.4060322,5.5000,5.5000,5.5000,-0.89266452,0.67462169,0.45153755,0.46551865,-0.076130454,-0.66425348,-1.2081157,-0.51115022,1.6387124,-0.64745486,-1.6698666,-0.74038664,-0.69924298,0.37227637,0.16178595,-1.17264,-0.71848908,1.8095423,0.010359525,-1.1241659,0.62170784,0.098617436,0.27461988,-0.95071744,-2.4924403,-0.4571527,-0.41290265,-0.81975673,-0.73656785,1.2451721,0.24027318,-1.712634,-0.57254915,-0.07672439,-0.21620712,-1.7291799,0.53277971,1.7531018,-1.0629718,-0.61666085,1.1318439,0.93353562,-0.97529073,-1.2232098,0.13945194,0.12996751,-0.055554052,1.0037703,-1.1941573,-0.071397915,0.62085587,-0.77222205,0.36658856,1.0853388,0.036862009,0.089183199,-0.028491993,0.21308086,0.8375961,0.0079837423,-0.097546195,-0.34055232,0.23007449,0.21089882,1.1785045,0.20617355,-0.506373,0.36012109,0.16505254,0.77278449,0.73317844,0.48227372,-0.025639033,-0.25015102,-0.2692608,0.28320445,0.92129948,1.4217527,0.7104685,-1.2510366,-0.49944257,0.38856213,0.4553264,0.40344429,0.47610599,0.06011708,0.21324589,0.89100884,0.19840868,0.46459082,0.74176549,0.64078734,1.0137924,1.3850456,0.22356434,1.7872519,2.9593237,0.10667143,-0.40214704,1.015946,1.428355,0.73060459,0.90340466,0.60647692,-0.013580252,-1.0316801,0.42430104,0.90641245,-1.9263364,-0.33216794,0.44815071,-0.16872166,-0.39027819,0.21364435,0.69924183,-0.54796628,-1.1666266,-0.40995402,1.1178553,1.2067864,-1.9084579,-0.51492214,1.7912186,1.375922,0.56148132,1.3251821,0.46330121,-0.56276386,0.73316969,0.50662582,0.80399311
#regular sample:
#0.89486742, -0.003822158, -0.75105205, -1.3965429, -1.7378376, -2.1130203, -2.2132096, -2.2033471, -2.0241906, -1.5914581, -1.0499022, -0.57789108, -0.3131374, -0.20084404, -0.18379899, 0.016525057, 0.50921179, 0.77751147, 0.75067496, 0.78843003, 0.77137524, 0.73257374, 0.67985885, 0.62183591, 0.60469296, 0.58129958, 0.65998204, 0.63413413, 0.63558912, 0.76050608, 0.76912011, 0.73457027, 0.72108854, 0.75040232, 0.62612794, 0.51689273, 0.54554218, 0.50588773, 0.5258932, 0.49186076, 0.52836623, 0.62282844, 0.58039006, 0.54824181, 0.50770483, 0.51204975, 0.40906504, 0.31038144, 0.36845009, 0.38137005, 0.33419976, 0.18130539, 0.20183031, 0.2933171, 0.27945872, 0.29958438, 0.21474396, 0.18456487, 0.13197654, 0.057778811, 0.018044803, -0.071802363, 0.005535548, 0.066041, 0.042362944, 0.05525463, -0.005126899, -0.051986345, -0.015207146, -0.0094131254, 0.02094263, 0.092754939, 0.00073659051, -0.071986495, 0.070326647, 0.091355005, 0.028342719, 0.17460518, 0.28679751, 0.27782832, 0.31537371, 0.31602348, 0.36637824, 0.44613065, 0.41105086, 0.42461382, 0.4831252, 0.4544008, 0.46774525, 0.56968959, 0.54844061, 0.52878176, 0.63875397, 0.64354817, 0.62231549, 0.6227605, 0.57584803, 0.56640109, 0.56635399, 0.57809064, 0.61300844, 0.63278994, 0.59456305, 0.61561681, 0.72445263, 0.7123046, 0.67086495, 0.71278444, 0.66167141, 0.58293314, 0.58568763, 0.61013419, 0.69306756, 0.68844189, 0.61338458, 0.60209334, 0.42122252, 0.16604014, 0.14347481, 0.19632701, 0.16141046, 0.1275313, -0.018672703, -0.23865283, -0.3706969, -0.59290109, -0.63411579, -0.44082747, -0.5180703, -0.70243851, -0.89974628, -1.4415163, -1.8616119, -2.3213812, -2.8848769, -3.530246, -4.4125149, -3.9033308, -3.5671064, -1.5363381
    def send_floats(self, float_values: list[float], delay: float = 0.001):
        if len(float_values) != 140:
            raise ValueError(f"Expected 140 floats, got {len(float_values)}")

        self.port, self.baudrate = self.get_serial_params()

        for val in float_values:
            packet = struct.pack('<f', val)  # Little-endian 4-byte float
            self.ser.write(packet)
            time.sleep(delay)  # Optional pacing

    def send_text_line(self, text: str):
        float_values = [float(val) for val in text.strip().split(',') if val.strip()]
        if len(float_values) != 140:
            raise ValueError(f"Expected 140 floats, got {len(float_values)}")

        self.send_floats(float_values)

    def send_line(self):
        try:

            text = self.ui.lineEdit.text()
            self.send_text_line(text)
            self.ui.plainTextEditReport.appendPlainText(f"[TX] Sent {140} floats from GUI input")
        except Exception as ex:
            self.ui.plainTextEditReport.appendPlainText(f"[ERROR] Invalid float input: {ex}")

    def on_sendFileButton_clicked(self):

        file_path, _ = QFileDialog.getOpenFileName(
            None,
            "Select Input File",
            "",
            "CSV Files (*.csv);;Text Files (*.txt);;All Files (*)"
        )

        if file_path:

            try:
                with open(file_path, 'r') as f:
                    for line_num, line in enumerate(f, start=1):
                        try:
                            self.send_text_line(line)
                            self.ser.flush()
                            time.sleep(0.05)
                        except Exception as ex:
                            print(f"[WARN] Line {line_num}: Skipped due to error: {ex}")

                print(f"[OK] Finished sending: {file_path}")

            except Exception as e:
                print(f"[ERROR] Failed to send file: {e}")

    def echo(self):
        self.port, self.baudrate = self.get_serial_params()

        if self.ser is None or not self.ser.is_open:
            try:
                self.ser = serial.Serial(self.port, self.baudrate, timeout=0.1)
                time.sleep(2)  # Allow time for MCU reset via DTR, if applicable
            except Exception as ex:
                self.ui.plainTextEditReport.appendPlainText(f"[ERROR] Failed to open serial port: {ex}")
                return

        try:
            report_text = self.ui.plainTextEditReport.toPlainText()
            lines = report_text.splitlines()  # This preserves content safely
            for line in lines:
                line_bytes = (line + '\r\n').encode('utf-8')
                self.ser.write(line_bytes)
                time.sleep(0.01)  # Optional pacing

            self.ui.plainTextEditReport.appendPlainText(f"[TX] Echoed {len(lines)} lines.")

        except Exception as ex:
            self.ui.plainTextEditReport.appendPlainText(f"[ERROR] Failed to echo: {ex}")
if __name__ == "__main__":
    app = QApplication(sys.argv)
    widget = COMPort()
    widget.show()
    sys.exit(app.exec())
